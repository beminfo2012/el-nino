document.addEventListener("DOMContentLoaded", function() {
    
    // Register datalabels plugin
    Chart.register(ChartDataLabels);

    // Global Chart Defaults
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.color = "#718096";
    Chart.defaults.scale.grid.color = "#EDF2F7";

    // Fetch Weather Open-Meteo
    fetch('/api/weather')
        .then(response => response.json())
        .then(data => {
            const statEl = document.getElementById('weather-status');
            if (data.error) {
                document.getElementById('weather-temp').innerText = "--";
                statEl.innerText = "Falha ao carregar";
                statEl.style.color = "#EF4444";
            } else {
                document.getElementById('weather-temp').innerText = Math.round(data.temp);
                document.getElementById('weather-chuva').innerText = data.chuva;
                document.getElementById('weather-umidade').innerText = data.umidade;
                document.getElementById('weather-vento').innerText = data.vento;
                statEl.innerText = "Tempo Real";
                statEl.style.color = "#10B981";

                // Renderizar previsão de 7 dias
                if (data.forecast && data.forecast.length > 0) {
                    const container = document.getElementById('weather-forecast');
                    container.innerHTML = '';
                    data.forecast.forEach((day, i) => {
                        const icon = getWeatherIcon(day.code, day.chuva);
                        const bg = i === 0 ? 'background: linear-gradient(135deg, #EFF6FF, #DBEAFE); border: 1px solid #BFDBFE;' : 'background: #F8FAFC;';
                        container.innerHTML += `
                            <div style="flex: 1; text-align: center; padding: 10px 6px; border-radius: 10px; ${bg}">
                                <div style="font-size: 0.72rem; font-weight: 700; color: #64748B;">${day.dia}</div>
                                <div style="font-size: 0.68rem; color: #94A3B8; margin-bottom: 5px;">${day.data}</div>
                                <div style="font-size: 1.5rem; margin: 4px 0;">${icon}</div>
                                <div style="font-size: 0.82rem; font-weight: 800; color: #DC2626;">${Math.round(day.max)}°</div>
                                <div style="font-size: 0.75rem; color: #64748B;">${Math.round(day.min)}°</div>
                                <div style="font-size: 0.65rem; color: #3B82F6; margin-top: 4px;">${day.chuva}% 🌧</div>
                            </div>`;
                    });
                }
            }
        }).catch(() => {
            document.getElementById('weather-status').innerText = "Erro";
        });

    function getWeatherIcon(code, chuva) {
        if (code === 0) return '☀️';
        if (code <= 2) return '🌤️';
        if (code <= 3) return '☁️';
        if (code <= 48) return '🌫️';
        if (code <= 57) return '🌦️';
        if (code <= 67) return '🌧️';
        if (code <= 77) return '❄️';
        if (code <= 82) return '🌧️';
        if (code <= 99) return '⛈️';
        if (chuva >= 60) return '🌧️';
        if (chuva >= 30) return '🌦️';
        return '🌤️';
    }

    // Fetch Hidroweb Telemetry
    fetch('/api/hidroweb')
        .then(response => response.json())
        .then(data => {
            const valEl = document.getElementById('hidroweb-valor');
            const statEl = document.getElementById('hidroweb-status');
            if (data.error || !data.nivel) {
                valEl.innerText = "Indisponível";
                statEl.innerText = "ANA Indisponível";
                statEl.style.color = "#EF4444";
            } else {
                valEl.innerText = data.nivel;
                if (data.vazao) document.getElementById('hidroweb-vazao').innerText = data.vazao;
                if (data.chuva) document.getElementById('hidroweb-chuva').innerText = data.chuva;
                if (data.data_hora) {
                    const dt = data.data_hora.trim().replace('  ', ' ');
                    document.getElementById('hidroweb-datahora').innerText = 'Leitura: ' + dt.substring(0, 16);
                }
                statEl.innerText = "✅ Dados Reais ANA";
                statEl.style.color = "#10B981";

                // Renderizar gráfico de nível mensal
                if (data.nivel_mensal) {
                    const ctxNivel = document.getElementById('hidroweb-nivelChart').getContext('2d');
                    new Chart(ctxNivel, {
                        type: 'line',
                        data: {
                            labels: data.nivel_mensal.labels,
                            datasets: [{
                                label: 'Nível (cm)',
                                data: data.nivel_mensal.values,
                                borderColor: '#0F4C81',
                                backgroundColor: 'rgba(15, 76, 129, 0.08)',
                                borderWidth: 2.5,
                                pointBackgroundColor: data.nivel_mensal.values.map((v, i) =>
                                    i === data.nivel_mensal.values.length - 1 ? '#E53E3E' : '#0F4C81'
                                ),
                                pointRadius: data.nivel_mensal.values.map((v, i) =>
                                    i === data.nivel_mensal.values.length - 1 ? 6 : 4
                                ),
                                pointBorderColor: '#fff',
                                pointBorderWidth: 2,
                                fill: true,
                                tension: 0.35
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { display: false },
                                datalabels: { display: false }
                            },
                            scales: {
                                y: {
                                    beginAtZero: false,
                                    grid: { color: '#EFF6FF' },
                                    ticks: { font: { size: 10 } }
                                },
                                x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                            }
                        }
                    });
                }
            }
        }).catch(() => {
            document.getElementById('hidroweb-status').innerText = "Erro de Conexão";
        });

    // Fetch Dashboard Data
    fetch('/api/data')
        .then(response => response.json())
        .then(data => {
            // Render Educação
            renderSection('educacao', data.educacao);
            // Render Saúde
            renderSection('saude', data.saude);
            // Render Cesan
            if(data.cesan) {
                renderCesan(data.cesan);
            }
            // Render Incêndios
            if(data.incendios) {
                renderIncendios(data.incendios);
            }
            // Render Drenagem
            if(data.drenagem) {
                renderDrenagem(data.drenagem);
            }
            // Render Educação (Rede Municipal — El Niño)
            if(data.educacao_novo) {
                renderEducacaoNovo(data.educacao_novo);
            }
            // Render Assistência Social
            if(data.assistencia_social) {
                renderAssistenciaSocial(data.assistencia_social);
            }
            // Render Vigilância Vetorial
            if(data.vigilancia_vetorial) {
                renderVigilanciaVetorial(data.vigilancia_vetorial);
            }
        });

    function renderAssistenciaSocial(d) {
        // Tabela de ações
        const tbody = document.getElementById('as-tbody');
        if (tbody && d.acoes && d.acoes.length) {
            tbody.innerHTML = '';
            d.acoes.forEach(r => {
                const statusBadge = r.status === 'Concluído'
                    ? `<span class="badge-concluido">${r.status}</span>`
                    : r.status === 'Em Andamento'
                        ? `<span class="badge-andamento">${r.status}</span>`
                        : `<span class="badge-manutencao">${r.status}</span>`;
                tbody.innerHTML += `<tr>
                    <td>${r.data}</td>
                    <td>${r.local}</td>
                    <td>${r.acao}</td>
                    <td>${r.familias}</td>
                    <td>${statusBadge}</td>
                </tr>`;
            });
        }

        // Estoque de itens de abrigo
        const estoqueEl = document.getElementById('as-estoque');
        if (estoqueEl && d.estoque && d.estoque.length) {
            const badgeMap = { 'Adequado': 'badge-concluido', 'Atenção': 'badge-andamento', 'Crítico': 'badge-construcao' };
            estoqueEl.innerHTML = d.estoque.map(item => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid #EFF6FF; font-size:0.82rem;">
                    <div>
                        <div style="font-weight:600; color:#1E293B;">${item.nome}</div>
                        <div style="font-size:0.72rem; color:#64748B;">${item.cobertura}</div>
                    </div>
                    <span class="${badgeMap[item.status] || 'badge-andamento'}">${item.status}</span>
                </div>`).join('');
        }

        // Gráfico: Demanda por Benefícios Eventuais (linha)
        if (d.beneficios_mes) {
            const tierColor = v => v < 15 ? '#2F855A' : v < 25 ? '#DD6B20' : '#E53E3E';
            const ctx = document.getElementById('as-beneficiosChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: d.beneficios_mes.labels,
                    datasets: [{
                        data: d.beneficios_mes.values,
                        borderColor: '#553C9A',
                        backgroundColor: 'rgba(85,60,154,0.08)',
                        borderWidth: 2.5, fill: true, tension: 0.35,
                        pointRadius: 5,
                        pointBackgroundColor: d.beneficios_mes.values.map(tierColor),
                        pointBorderColor: '#fff', pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, datalabels: { display: false } },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F5F3FF' }, ticks: { font: { size: 10 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    }
                }
            });
        }

        // Gráfico: Atendimentos por Localidade (barra horizontal)
        if (d.atendimentos_local) {
            const ctx2 = document.getElementById('as-localidadeChart').getContext('2d');
            new Chart(ctx2, {
                type: 'bar',
                data: {
                    labels: d.atendimentos_local.labels,
                    datasets: [{ data: d.atendimentos_local.values, backgroundColor: '#0F4C81', borderRadius: 5, maxBarThickness: 22 }]
                },
                options: {
                    indexAxis: 'y', responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, datalabels: { color: '#fff', align: 'end', anchor: 'end', font: { weight: 'bold' } } },
                    scales: {
                        x: { beginAtZero: true, grid: { color: '#EFF6FF' }, ticks: { font: { size: 10 } } },
                        y: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    }
                }
            });
        }

        // Gráfico: Distribuição por tipo de ação (donut)
        if (d.tipo_acao) {
            const ctx3 = document.getElementById('as-tipoChart').getContext('2d');
            new Chart(ctx3, {
                type: 'doughnut',
                data: {
                    labels: d.tipo_acao.labels,
                    datasets: [{ data: d.tipo_acao.values, backgroundColor: ['#553C9A','#E53E3E','#2F855A','#0F4C81'], borderWidth: 0 }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false, cutout: '62%',
                    plugins: { legend: { position: 'bottom', labels: { font: { size: 10 }, boxWidth: 10, padding: 10 } }, datalabels: { display: false } }
                }
            });
        }
    }

    function renderVigilanciaVetorial(d) {
        // Tabela de ações de controle vetorial
        const tbody = document.getElementById('vv-tbody');
        if (tbody && d.acoes && d.acoes.length) {
            tbody.innerHTML = '';
            d.acoes.forEach(r => {
                const statusBadge = r.status === 'Concluído'
                    ? `<span class="badge-concluido">${r.status}</span>`
                    : r.status === 'Em Andamento'
                        ? `<span class="badge-andamento">${r.status}</span>`
                        : `<span class="badge-manutencao">${r.status}</span>`;
                tbody.innerHTML += `<tr>
                    <td>${r.data}</td>
                    <td>${r.local}</td>
                    <td>${r.acao}</td>
                    <td>${r.focos_eliminados}</td>
                    <td>${statusBadge}</td>
                </tr>`;
            });
        }

        // Estoque de insumos estratégicos
        const estoqueEl = document.getElementById('vv-estoque');
        if (estoqueEl && d.estoque && d.estoque.length) {
            const badgeMap = { 'Adequado': 'badge-concluido', 'Atenção': 'badge-andamento', 'Crítico': 'badge-construcao' };
            estoqueEl.innerHTML = d.estoque.map(item => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid #FFF1F2; font-size:0.82rem;">
                    <div>
                        <div style="font-weight:600; color:#1E293B;">${item.nome}</div>
                        <div style="font-size:0.72rem; color:#64748B;">${item.cobertura}</div>
                    </div>
                    <span class="${badgeMap[item.status] || 'badge-andamento'}">${item.status}</span>
                </div>`).join('');
        }

        // Gráfico: Evolução de casos de dengue (linha)
        if (d.casos_dengue) {
            const tierColor = v => v < 12 ? '#2F855A' : v < 20 ? '#DD6B20' : '#E53E3E';
            const ctx = document.getElementById('vv-casosChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: d.casos_dengue.labels,
                    datasets: [{
                        data: d.casos_dengue.values,
                        borderColor: '#97266D',
                        backgroundColor: 'rgba(151,38,109,0.08)',
                        borderWidth: 2.5, fill: true, tension: 0.35,
                        pointRadius: 5,
                        pointBackgroundColor: d.casos_dengue.values.map(tierColor),
                        pointBorderColor: '#fff', pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, datalabels: { display: false } },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#FCE7F3' }, ticks: { font: { size: 10 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    }
                }
            });
        }

        // Gráfico: Índice LIRAa por região (barra horizontal colorida)
        if (d.liraa) {
            const liraaColors = d.liraa.values.map(v => v < 1 ? '#2F855A' : v < 4 ? '#DD6B20' : '#E53E3E');
            const ctx2 = document.getElementById('vv-liraaChart').getContext('2d');
            new Chart(ctx2, {
                type: 'bar',
                data: {
                    labels: d.liraa.labels,
                    datasets: [{ data: d.liraa.values, backgroundColor: liraaColors, borderRadius: 5, maxBarThickness: 22 }]
                },
                options: {
                    indexAxis: 'y', responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, datalabels: { color: '#fff', align: 'end', anchor: 'end', font: { weight: 'bold' }, formatter: v => v+'%' } },
                    scales: {
                        x: { beginAtZero: true, grid: { color: '#FCE7F3' }, ticks: { font: { size: 10 }, callback: v => v+'%' } },
                        y: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    }
                }
            });
        }

        // Gráfico: Casos por localidade (barra horizontal)
        if (d.casos_local) {
            const ctx3 = document.getElementById('vv-localChart').getContext('2d');
            new Chart(ctx3, {
                type: 'bar',
                data: {
                    labels: d.casos_local.labels,
                    datasets: [{ data: d.casos_local.values, backgroundColor: '#97266D', borderRadius: 5, maxBarThickness: 22 }]
                },
                options: {
                    indexAxis: 'y', responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, datalabels: { color: '#fff', align: 'end', anchor: 'end', font: { weight: 'bold' } } },
                    scales: {
                        x: { beginAtZero: true, grid: { color: '#FCE7F3' }, ticks: { font: { size: 10 } } },
                        y: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    }
                }
            });
        }
    }

    function renderEducacaoNovo(d) {
        // ── Gráfico de Absenteísmo (linha com cores por nível) ──────────────
        if (d.absenteismo_semanal) {
            const tierColor = v => v < 5 ? '#2F855A' : v < 7 ? '#DD6B20' : '#E53E3E';
            const ctx = document.getElementById('edu-absenteismoChart');
            if (ctx) {
                new Chart(ctx.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: d.absenteismo_semanal.labels,
                        datasets: [{
                            data: d.absenteismo_semanal.values,
                            borderColor: '#2F855A',
                            backgroundColor: 'rgba(47,133,90,0.08)',
                            borderWidth: 2.5,
                            fill: true,
                            tension: 0.35,
                            pointRadius: 6,
                            pointBackgroundColor: d.absenteismo_semanal.values.map(tierColor),
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            datalabels: {
                                display: true,
                                align: 'top',
                                color: ctx => tierColor(d.absenteismo_semanal.values[ctx.dataIndex]),
                                font: { weight: 'bold', size: 10 },
                                formatter: v => v + '%'
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: '#F0FDF4' },
                                ticks: { font: { size: 10 }, callback: v => v + '%' }
                            },
                            x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                        }
                    }
                });
            }
        }

        // ── Tabela de Ocorrências ────────────────────────────────────────────
        const tbody = document.getElementById('edu-tbody');
        if (tbody && d.ocorrencias && d.ocorrencias.length) {
            const badgeMap = {
                'Concluído':    'badge-concluido',
                'Em Andamento': 'badge-andamento',
                'Planejado':    'badge-construcao'
            };
            tbody.innerHTML = '';
            d.ocorrencias.forEach(r => {
                const badge = `<span class="${badgeMap[r.status] || 'badge-andamento'}">${r.status}</span>`;
                tbody.innerHTML += `<tr>
                    <td>${r.data}</td>
                    <td>${r.escola}</td>
                    <td>${r.motivo}</td>
                    <td>${r.acao}</td>
                    <td>${badge}</td>
                </tr>`;
            });
        }

        // ── Infraestrutura e Planejamento ────────────────────────────────────
        const infraEl = document.getElementById('edu-infraestrutura');
        if (infraEl && d.infraestrutura && d.infraestrutura.length) {
            const badgeMap = {
                'Concluído':    'badge-concluido',
                'Em Andamento': 'badge-andamento',
                'Pendente':     'badge-construcao'
            };
            infraEl.innerHTML = d.infraestrutura.map(item => `
                <div style="display:flex; justify-content:space-between; align-items:center;
                            padding:10px 0; border-bottom:1px solid #DCFCE7; font-size:0.83rem;">
                    <div>
                        <div style="font-weight:600; color:#1E293B;">${item.nome}</div>
                        <div style="font-size:0.72rem; color:#64748B; margin-top:2px;">${item.descricao}</div>
                    </div>
                    <span class="${badgeMap[item.status] || 'badge-andamento'}">${item.status}</span>
                </div>`).join('');
        }
    }

    function renderDrenagem(registros) {
        const tbody = document.getElementById('drenagem-tbody');
        if (!tbody || !registros || registros.length === 0) return;

        let totalManut = 0, totalConst = 0, totalKm = 0;

        tbody.innerHTML = '';
        registros.forEach(r => {
            const tipoBadge = r.tipo === 'Manutenção'
                ? `<span class="badge-manutencao">${r.tipo}</span>`
                : `<span class="badge-construcao">${r.tipo}</span>`;
            const statusBadge = r.status === 'Concluído'
                ? `<span class="badge-concluido">${r.status}</span>`
                : `<span class="badge-andamento">${r.status}</span>`;

            tbody.innerHTML += `<tr>
                <td>${r.data}</td>
                <td>${tipoBadge}</td>
                <td>${r.local}</td>
                <td>${r.descricao}</td>
                <td>${r.extensao_m}</td>
                <td>${statusBadge}</td>
            </tr>`;

            if (r.tipo === 'Manutenção') totalManut++;
            else totalConst++;
            totalKm += parseInt(r.extensao_m) || 0;
        });

        document.getElementById('drenagem-total').innerText = registros.length;
        document.getElementById('drenagem-manutencoes').innerText = totalManut;
        document.getElementById('drenagem-construcoes').innerText = totalConst;
        document.getElementById('drenagem-km').innerText = totalKm;

        // Gráfico por localidade
        const contagem = {};
        registros.forEach(r => { contagem[r.local] = (contagem[r.local] || 0) + 1; });
        const labels = Object.keys(contagem);
        const valores = Object.values(contagem);

        const ctx = document.getElementById('drenagem-locaisChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Intervenções',
                    data: valores,
                    backgroundColor: '#0F4C81',
                    borderRadius: 5
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false }, datalabels: { color: '#fff', align: 'end', anchor: 'end', font: { weight: 'bold' } } },
                scales: { x: { beginAtZero: true }, y: { grid: { display: false } } }
            }
        });
    }

    function renderIncendios(data) {
        // Gráfico Evolução (Linha/Área)
        const ctxEvol = document.getElementById('incendios-evolucaoChart').getContext('2d');
        new Chart(ctxEvol, {
            type: 'line',
            data: {
                labels: data.evolucao_labels,
                datasets: [{
                    label: 'Focos Registrados',
                    data: data.evolucao_dados,
                    borderColor: '#E53E3E', // Red-500
                    backgroundColor: 'rgba(229, 62, 62, 0.15)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#C53030',
                    pointBorderColor: '#fff',
                    pointRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    datalabels: {
                        color: '#C53030',
                        align: 'top',
                        font: { weight: 'bold' }
                    }
                },
                scales: {
                    y: { beginAtZero: true, grid: { color: '#FEE2E2' } },
                    x: { grid: { display: false } }
                }
            }
        });

        // Gráfico Locais (Barra Horizontal)
        const ctxLocais = document.getElementById('incendios-locaisChart').getContext('2d');
        new Chart(ctxLocais, {
            type: 'bar',
            data: {
                labels: data.locais_labels,
                datasets: [{
                    label: 'Ocorrências',
                    data: data.locais_dados,
                    backgroundColor: '#DD6B20', // Orange-500
                    borderRadius: 4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    datalabels: {
                        color: '#fff',
                        align: 'end',
                        anchor: 'end',
                        font: { weight: 'bold' }
                    }
                },
                scales: {
                    x: { beginAtZero: true, grid: { color: '#FFEDD5' } },
                    y: { grid: { display: false } }
                }
            }
        });
    }

    function renderCesan(data) {
        // ── Badges de Status por Captação ────────────────────────────────────
        if (data.captacoes && data.captacoes.length) {
            const statusStyle = {
                'Normal':   { bg: '#DCFCE7', color: '#2F855A', border: '#2F855A' },
                'Atenção':  { bg: '#FEF3C7', color: '#B45309', border: '#DD6B20' },
                'Alerta':   { bg: '#FFEDD5', color: '#C2410C', border: '#DD6B20' },
                'Crítico':  { bg: '#FEE2E2', color: '#C53030', border: '#E53E3E' }
            };
            data.captacoes.forEach(cap => {
                const badgeEl = document.getElementById(`cesan-status-${cap.num}`);
                const cardEl  = badgeEl ? badgeEl.closest('.card') : null;
                const style   = statusStyle[cap.status] || statusStyle['Normal'];
                if (badgeEl) {
                    badgeEl.innerText          = cap.status.toUpperCase();
                    badgeEl.style.background   = style.bg;
                    badgeEl.style.color        = style.color;
                }
                if (cardEl) {
                    cardEl.style.borderLeftColor = style.border;
                }
            });
        }

        // ── Gráfico de Linha do Tempo ─────────────────────────────────────────
        if (!data.timeline_labels || data.timeline_labels.length === 0) return;

        const ctx = document.getElementById('cesan-timelineChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.timeline_labels,
                datasets: [{
                    label: 'Status da Captação',
                    data: data.timeline_values,
                    borderColor: '#0F4C81',
                    backgroundColor: 'rgba(15, 76, 129, 0.1)',
                    borderWidth: 3,
                    pointBackgroundColor: data.timeline_values.map(v => {
                        if (v === 3) return '#E53E3E'; // Crítico
                        if (v === 2) return '#DD6B20'; // Alerta
                        if (v === 1) return '#FCD34D'; // Atenção
                        return '#2F855A';              // Normal
                    }),
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    fill: true,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    datalabels: {
                        display: true,
                        align: 'top',
                        color: '#1E293B',
                        font: { weight: 'bold' },
                        formatter: function(value, context) {
                            return data.timeline_status[context.dataIndex];
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 3.5,
                        ticks: {
                            stepSize: 1,
                            callback: function(value) {
                                if (value === 3) return 'Crítico (3)';
                                if (value === 2) return 'Alerta (2)';
                                if (value === 1) return 'Atenção (1)';
                                if (value === 0) return 'Normal (0)';
                                return '';
                            }
                        }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    function renderSection(prefix, data) {
        initTipologia(prefix, data.tipologia_risco);
        initOcorrencias(prefix, data.ocorrencias_tipo);
        initTopLocalidades(prefix, data.top_5_localidades);
    }

    // =======================
    // EXPORTAR PDF (NOVO RELATÓRIO OFICIAL)
    // =======================
    window.exportarPDF = function() {
        const btn = document.getElementById('btn-exportar-pdf');
        btn.innerText = '⏳ Gerando Documento...';
        btn.disabled = true;

        // Abre a nova rota oficial em uma nova aba
        window.open('/relatorio', '_blank');

        setTimeout(() => {
            btn.innerText = '📄 Exportar Relatório PDF';
            btn.disabled = false;
        }, 1500);
    };

    function initTipologia(prefix, data) {
        document.getElementById(`${prefix}-tipologiaTotal`).innerText = data.total;
        
        const colors = ['#718096', '#2F855A', '#0F4C81', '#DD6B20'];
        
        // Build Legend
        const legendContainer = document.getElementById(`${prefix}-tipologiaLegend`);
        legendContainer.innerHTML = ''; // Clear existing
        data.labels.forEach((label, i) => {
            const perc = data.total > 0 ? ((data.values[i] / data.total) * 100).toFixed(1) : 0;
            legendContainer.innerHTML += `
                <div class="legend-row">
                    <div class="legend-label">
                        <span class="dot" style="background-color: ${colors[i]}"></span>
                        <div>${label} <br> <span class="val-number">${data.values[i]}</span></div>
                    </div>
                    <div class="legend-values">
                        <span class="val-perc">${perc}%</span>
                    </div>
                </div>
            `;
        });

        const ctx = document.getElementById(`${prefix}-tipologiaChart`).getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: colors,
                    borderWidth: 0,
                    cutout: '70%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    datalabels: { display: false }
                }
            }
        });
    }

    function initOcorrencias(prefix, data) {
        const ctx = document.getElementById(`${prefix}-ocorrenciasTipoChart`).getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: '#0F4C81',
                    borderRadius: 4,
                    barPercentage: 0.4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    datalabels: { 
                        display: true, 
                        anchor: 'end',
                        align: 'end',
                        color: '#1E293B',
                        font: { weight: 'bold' }
                    }
                },
                scales: {
                    x: { display: false },
                    y: { grid: { display: false }, border: {display: false} }
                }
            }
        });
    }

    function initTopLocalidades(prefix, data) {
        const ctx = document.getElementById(`${prefix}-topLocalidadesChart`).getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: '#DD6B20',
                    borderRadius: 4,
                    barPercentage: 0.4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    datalabels: { 
                        display: true, 
                        anchor: 'end',
                        align: 'end',
                        color: '#1E293B',
                        font: { weight: 'bold' }
                    }
                },
                scales: {
                    x: { display: false },
                    y: { grid: { display: false }, border: {display: false} }
                }
            }
        });
    }
});
